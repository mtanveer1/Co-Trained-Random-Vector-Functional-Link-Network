function [trainX_T,testX_T]=initialze_SP_RVFL_Weights(trainX,testX,name)
%% RVFL
parameter_path='./New_Results_Varied_C1_C2/SP-RVFL/';
filename = [parameter_path 'Res_' name '.mat'];
load (filename, 'OptPara');
%% SP-RVFL
beta1=OptPara.model.beta1;
scale=OptPara.Scale;
%% Train
H1 = trainX * beta1;
l3 = max(max(H1));l3 = scale/l3;
H1 = radbas(H1 * l3);
trainX_T = [trainX H1];
clear H1
%% Test
H1 = testX* beta1;
H1= radbas(H1*l3);
testX_T = [testX H1];
end