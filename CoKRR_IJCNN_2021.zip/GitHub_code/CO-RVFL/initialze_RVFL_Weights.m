function [trainX_T,testX_T,trainY_temp]=initialze_RVFL_Weights(trainX,trainY,testX,name)
%% Encode Weights
[Nsample,Nfea] = size(trainX);
U_trainY = unique(trainY);
nclass = numel(U_trainY);
trainY_temp = zeros(Nsample,nclass);

% 0-1 coding for the target
for i=1:nclass
    idx = trainY==U_trainY(i);
    
    trainY_temp(idx,i) = 1;
end

parameter_path='./New_Results_Varied_C1_C2/RVFL/';
filename = [parameter_path 'Res_' name '.mat'];
load (filename, 'OptPara');
W=OptPara.model.W;
b=OptPara.model.b;

X1 = trainX*W+repmat(b,Nsample,1);
actfun_selected=OptPara.ActivationFunction;
switch actfun_selected
    case 1
        X1 = radbas(X1);
    case 2
        X1 = sin(X1);
    case 3
        X1 = tribas(X1);
        %case 4
        %X1 = 1 ./ (1 + exp(-X1));
end
X1(isnan(X1))=0;
X1 = [X1,ones(Nsample,1)];%bias is added
trainX_T = [trainX,X1]; %input to the output layer
clear X1
%%
X=testX;
[m,~] = size(X);
X1 = X*W+repmat(b,m,1);
switch actfun_selected
    case 1
        X1 = radbas(X1);
    case 2
        X1 = sin(X1);
    case 3
        X1 = tribas(X1);
        %case 4
        %X1 = 1 ./ (1 + exp(-X1));
end
X1=[X1,ones(size(X,1),1)];
testX_T = [X,X1];