function [train_acc,test_acc]=CoKRVFL(trainH1,trainH2,trainY,testH1,testH2,testY,option,Ulabel)
%% train
train_acc=zeros(4,1);
lambda1=option.C1;lambda2=option.C2;lambda3=option.C3;

K1=trainH1;
K2=trainH2;
nu=lambda3+1;
tic
I1=eye(size(K1));
I2=eye(size(K2));
alpha=(nu*K1+lambda1*I1-4*lambda3^2*K2*((nu*K2+lambda2*I2)\K1))\(trainY+2*lambda3*K2*((nu*K2+lambda2*I2)\trainY));
beta=(nu*K2+lambda2*I2-4*lambda3^2*K1*((nu*K1+lambda1*I1)\K2))\(trainY+2*lambda3*K1*((nu*K1+lambda1*I1)\trainY));

train_time=toc;

model.alpha=alpha;
model.beta=beta;

Y1=K1*alpha;
Y2=K2*beta;

[Y1,val1,val1all]=oneVrestDecoding(Y1,Ulabel);
[Y2,val2,val2all]=oneVrestDecoding(Y2,Ulabel);
Y3=val1all+val2all;
[Y3,~]=oneVrestDecoding(Y3,Ulabel);
Y4=Y1;
idx=find(val1<val2);
Y4(idx)=Y2(idx);
[trainY,~,~]=oneVrestDecoding(trainY,Ulabel);
train_acc(1)=length(find(Y1==trainY))/length(trainY);
train_acc(2)=length(find(Y2==trainY))/length(trainY);
train_acc(3)=length(find(Y3==trainY))/length(trainY);
train_acc(4)=length(find(Y4==trainY))/length(trainY);

Kt1=testH1;
Kt2=testH2;

Yt1=Kt1*alpha;
Yt2=Kt2*beta;

[Yt1,val1,val1all]=oneVrestDecoding(Yt1,Ulabel);
[Yt2,val2,val2all]=oneVrestDecoding(Yt2,Ulabel);
Yt3=val1all+val2all;
[Yt3,~,~]=oneVrestDecoding(Yt3,Ulabel);

Yt4=Yt1;
idx=find(val1<val2);
Yt4(idx)=Yt2(idx);
test_acc=zeros(4,1);

test_acc(1)=length(find(Yt1==testY))/length(testY);
test_acc(2)=length(find(Yt2==testY))/length(testY); 
test_acc(3)=length(find(Yt3==testY))/length(testY);
test_acc(4)=length(find(Yt4==testY))/length(testY);
end