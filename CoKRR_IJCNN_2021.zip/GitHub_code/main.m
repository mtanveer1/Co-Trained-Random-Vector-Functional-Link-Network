
name='wall-following';
addpath(genpath(cd))
my_result_path='./New_Results_Varied_C1_C2/Co-Trained-RVFL_Max_of_Two/';
tot_data = importdata(['.\' name '\' name '_R.dat']);
tot_data=tot_data.data;
index_tune = importdata (['.\' name '\conxuntos.dat']);

if length(find(index_tune == 0))>0
    index_tune = index_tune + 1;
end

for k=1:size(index_tune,1)
    index_sep{k}=index_tune(k,~isnan(index_tune(k,:)));
end

%%% Removing first i.e. indexing column and seperate data and classes
data=tot_data(:,2:end);
dataX=data(:,1:end-1);
dataY=data(:,end);
clear tot_data data


mean_X=mean(dataX,1);
dataX=dataX-repmat(mean_X,size(dataX,1),1);
norm_X=sum(dataX.^2,1);
norm_X=sqrt(norm_X);
norm_eval = norm_X; 
norm_X=repmat(norm_X,size(dataX,1),1);
dataX=dataX./norm_X;
fold_index = importdata([datapath name '\conxuntos_kfold.dat']);

if length(find(fold_index == 0))>0
    fold_index = fold_index + 1;
end

for k=1:size(fold_index,1)
    index{k,1}=fold_index(k,~isnan(fold_index(k,:)));
end


filename = [my_result_path 'Res_' name '.mat'];
load (filename, 'OptPara');

temp_Acc=[];
n = 4;
ACC = zeros(1,n);
Model_tree = cell(1,n);
Net_Train_time=zeros(1,n);
for f=1:4
    trainX=dataX(index{2*f-1},:);
    trainY=dataY(index{2*f-1},:);
    testX=dataX(index{2*f},:);
    testY=dataY(index{2*f},:);

    [trainRVFL,testRVFL,trainY_temp]=initialze_RVFL_Weights(trainX,trainY,testX,name);
    [trainSPRVFL,testSPRVFL]=initialze_SP_RVFL_Weights(trainX,testX,name);

    [train_acc,test_acc]=CoKRVFL(trainRVFL,trainSPRVFL,trainY_temp,testRVFL,testSPRVFL,testY,...
        OptPara,unique(trainY));
    temp_Acc=[temp_Acc,test_acc];
    %ACC(1,f)=test_acc(3);% Average of Two
    ACC(1,f)=test_acc(4);% Maximum_of_TWO
    clear trainX trainY testX testY;
end
mean_acc = mean(ACC)